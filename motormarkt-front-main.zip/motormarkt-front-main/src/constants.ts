// constants.ts
'use strict';
export const API_URL = 'http://localhost:8000';
export const EMAIL = 'info@motormarkt.com';