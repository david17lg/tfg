package com.backend.motormarkt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MotorMarktApplicationTests {

	@Test
	void contextLoads() {
	}

}
